<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ERNST & CHARL</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/nivo-slider/css/nivo-slider.css" rel="stylesheet">
    <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <style>

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: red;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;} 
</style>
</head>

<body data-spy="scroll" data-target="#navbar-example">

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        <div class="container d-flex">

            <div class="logo mr-auto">
                <h1 class="text-light"><a href="index.php"><span>ERNST &</span>CHARL</a></h1>
                <!-- Uncomment below if you prefer to use an image logo -->
                <!-- <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
            </div>

            <nav class="nav-menu d-none d-lg-block">
                <ul>
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li class="dropdown"><a href="services.php">Services</a>
        <ul class="dropdown-content">
          <li><a href="./accounting.php">Accounting</a> </li>
          <li><a href="./audit.php"> Audit and Assurance</a> </li>
          <li><a href="./management.php">Management</a> </li>
          <li><a href="./companyreg.php"> Company Registration</a></li>
          <li><a href="./statutory.php">Statutory Compliance</a> </li>
          <li><a href="./secretarial.php">Coompany Secretarial</a> </li>
          <li><a href="./tax.php">Tax Services</a> </li>
          <li><a href="./other.php">Other Services</a> </li>

        </ul>
        </li>
                    <li><a href="team.php">Team</a></li>
                    <li><a href="portfolio.php">Portfolio</a></li>
                    <li><a href="contact.php">Contact</a></li>

                </ul>
                <div class="" style="display:flex; flex-direction:row; margin-top:3px;">

                    <a href="https://www.facebook.com/Ernst-Charl-Chartered-Certified-Accountants-107803084279156">
                        <i class="fa fa-facebook"></i>
                    </a>


                    <a href="https://twitter.com/CharlCertified">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="https://www.instagram.com/ernstcharlaccountants/?hl=en">
                        <i class="fa fa-instagram"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/ernst-charl-chartered-certified-accountants-0b07371b5">
          <i class="fa fa-linkedin"></i>
        </a>
                </div>
            </nav><!-- .nav-menu -->

        </div>
    </header><!-- End Header -->

    <div id="services" class="services-area area-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline services-head text-center">
                        <p>
                        <h2>Our Services</h2>
                        <h4>Tax Services</h4>
                        </p>
                    </div>
                </div>
            </div>

            <p>
            <h5>ZIMRA Registration</h5>
            </p>
            <p> All clients, including individuals, companies,
                partnerships and cooperatives who want to
                venture into any business are required to
                register with ZIMRA within 30 days and
                comply with all obligations as stipulated in
                the legislation like submitting timely returns
                and making timely payments.</p>
            <p>
            <h5>Filing tax returns</h5>
            </p>
            <p>
                The filing of tax returns is mandatory for all
                taxpayers and for one to get a tax clearance and comply with the law. E&C
                Business Solutions will assist you in filing your
                returns in a timely manner and make sure
                that you are a compliant taxpayer. We will
                handle your;
                <li>QPDs
                <li>PAYE returns (P2)
                <li>VAT returns
                <li>Income tax Annual Returns (ITF 12C)
            </p>
            <p>
            <h5> Tax planning.</h5>
            </p>
            <p>
                Arrangements of tax affairs to minimize tax
                liability through the use of all allowances,
                tax deductions, exclusions, exemptions
                among others to reduce income. Business
                people need to ensure that all statutory
                obligations are met and in time to avoid
                punitive measures such as garnish orders.
                We will make sure that you pay the least
                amount of tax possible within the confines
                of the law.</p>
            <p>
            <h5></h5>
            Tax Clearance certificate
            ITF 263</p>
            <p>
                This is issued by the Revenue Authority
                (ZIMRA) once a taxpayer has met all the
                stipulated obligations which include
                submission of tax returns and remittances of
                tax due. Failure to have a Tax Clearance
                certificate results in the deduction of 10% of
                the amount payable to the business
                (Withholding tax).</p>
</div>
</div>
                <?php include('./include/footer.php');?>
